import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Image from "next/image";
import { PortableText } from "@portabletext/react";
import { client } from "@/lib/sanity.client";
import { postBySlugQuery, allPostSlugsQuery } from "@/lib/queries";
import { urlFor } from "@/lib/sanity.image";
import type { SanityImageAsset } from "@/lib/types";
import type { PortableTextBlock } from "sanity";

export const revalidate = 60;

interface Post {
  title: string;
  excerpt?: string;
  coverImage?: SanityImageAsset;
  publishedAt?: string;
  body?: PortableTextBlock[];
  metaDescription?: string;
}

export async function generateStaticParams() {
  const slugs: { slug: string }[] = await client.fetch(allPostSlugsQuery);
  return slugs.map((s) => ({ slug: s.slug }));
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const post: Post | null = await client.fetch(postBySlugQuery, { slug: params.slug });
  if (!post) return {};
  return {
    title: post.title,
    description: post.metaDescription || post.excerpt,
  };
}

export default async function PostPage({ params }: { params: { slug: string } }) {
  const post: Post | null = await client.fetch(postBySlugQuery, { slug: params.slug });
  if (!post) notFound();

  return (
    <article className="container-catalog py-16 max-w-2xl mx-auto">
      <h1 className="text-display-2 mb-6">{post.title}</h1>
      {post.coverImage && (
        <div className="relative aspect-[16/9] mb-10 border border-line">
          <Image src={urlFor(post.coverImage).width(1200).height(675).url()} alt={post.coverImage.alt || post.title} fill className="object-cover" />
        </div>
      )}
      {post.body && (
        <div className="prose prose-neutral">
          <PortableText value={post.body} />
        </div>
      )}
    </article>
  );
}
