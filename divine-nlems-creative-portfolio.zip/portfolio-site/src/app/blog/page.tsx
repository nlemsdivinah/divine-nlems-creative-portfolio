import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { client } from "@/lib/sanity.client";
import { allPostsQuery } from "@/lib/queries";
import { urlFor } from "@/lib/sanity.image";
import type { SanityImageAsset } from "@/lib/types";

export const revalidate = 60;
export const metadata: Metadata = { title: "Journal", description: "Notes on design, branding, and process." };

interface Post {
  _id: string;
  title: string;
  slug: { current: string };
  excerpt?: string;
  coverImage?: SanityImageAsset;
  publishedAt?: string;
}

export default async function BlogPage() {
  const posts: Post[] = await client.fetch(allPostsQuery);

  return (
    <div className="container-catalog py-16">
      <p className="plate-number mb-2">JOURNAL</p>
      <h1 className="text-display-2 mb-12">Notes on design</h1>

      {posts.length === 0 && (
        <p className="font-mono text-sm text-ink/50">No posts published yet — add one in the CMS.</p>
      )}

      <div className="grid md:grid-cols-2 gap-10">
        {posts.map((post) => (
          <Link key={post._id} href={`/blog/${post.slug.current}`} className="group block">
            {post.coverImage && (
              <div className="relative aspect-[16/10] mb-4 overflow-hidden border border-line">
                <Image
                  src={urlFor(post.coverImage).width(800).height(500).url()}
                  alt={post.coverImage.alt || post.title}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                  sizes="(max-width: 768px) 100vw, 50vw"
                />
              </div>
            )}
            <h2 className="font-display font-bold text-xl group-hover:text-cobalt transition-colors">{post.title}</h2>
            {post.excerpt && <p className="text-sm text-ink/60 mt-2">{post.excerpt}</p>}
          </Link>
        ))}
      </div>
    </div>
  );
}
