import type { Metadata } from "next";
import { client } from "@/lib/sanity.client";
import { siteSettingsQuery } from "@/lib/queries";
import type { SiteSettings } from "@/lib/types";
import ContactForm from "@/components/ContactForm";

export const revalidate = 60;

export const metadata: Metadata = {
  title: "Contact",
  description: "Start a branding, packaging, or design project.",
};

export default async function ContactPage() {
  const settings: SiteSettings = await client.fetch(siteSettingsQuery);

  return (
    <div className="container-catalog py-16 grid md:grid-cols-[1fr_1.2fr] gap-14">
      <div>
        <p className="plate-number mb-2">GET IN TOUCH</p>
        <h1 className="text-display-2 mb-6">Let&apos;s talk about your project.</h1>
        <p className="text-ink/70 mb-10 max-w-sm">
          Tell me what you&apos;re building and I&apos;ll reply within one business day with next steps
          or a short discovery call link.
        </p>

        <dl className="space-y-4 font-mono text-sm">
          {settings?.email && (
            <div>
              <dt className="text-ink/50 text-xs uppercase mb-1">Email</dt>
              <dd><a href={`mailto:${settings.email}`} className="hover:text-cobalt underline">{settings.email}</a></dd>
            </div>
          )}
          {settings?.phone && (
            <div>
              <dt className="text-ink/50 text-xs uppercase mb-1">WhatsApp / Phone</dt>
              <dd><a href={`https://wa.me/${settings.phone.replace(/[^0-9]/g, "")}`} className="hover:text-cobalt underline">{settings.phone}</a></dd>
            </div>
          )}
          {settings?.location && (
            <div>
              <dt className="text-ink/50 text-xs uppercase mb-1">Location</dt>
              <dd>{settings.location}</dd>
            </div>
          )}
          {settings?.calendlyUrl && (
            <div>
              <dt className="text-ink/50 text-xs uppercase mb-1">Book a call</dt>
              <dd><a href={settings.calendlyUrl} target="_blank" rel="noopener noreferrer" className="hover:text-cobalt underline">Open scheduler ↗</a></dd>
            </div>
          )}
        </dl>
      </div>

      <ContactForm />
    </div>
  );
}
