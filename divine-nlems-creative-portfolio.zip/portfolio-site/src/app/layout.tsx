import type { Metadata } from "next";
import { Space_Grotesk, Inter, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { client } from "@/lib/sanity.client";
import { siteSettingsQuery } from "@/lib/queries";
import type { SiteSettings } from "@/lib/types";

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  weight: ["500", "700"],
  variable: "--font-space-grotesk",
  display: "swap",
});
const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
const plexMono = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["400", "500"],
  variable: "--font-plex-mono",
  display: "swap",
});

export async function generateMetadata(): Promise<Metadata> {
  const settings: SiteSettings = await client.fetch(siteSettingsQuery).catch(() => ({}));
  const title = settings?.metaTitle || "Divine Nlems — Creative Graphic Designer";
  const description =
    settings?.metaDescription ||
    "Brand identity, packaging, and digital design that turns first impressions into signed clients.";
  const url = process.env.NEXT_PUBLIC_SITE_URL || "https://www.example.com";

  return {
    metadataBase: new URL(url),
    title: { default: title, template: `%s — ${settings?.siteName || "Divine Nlems"}` },
    description,
    alternates: { canonical: "/" },
    openGraph: { title, description, url, siteName: settings?.siteName || "Divine Nlems", type: "website" },
    twitter: { card: "summary_large_image", title, description },
    robots: { index: true, follow: true },
  };
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "ProfessionalService",
    name: "Divine Nlems — Creative Graphic Design",
    serviceType: "Graphic Design",
    areaServed: "Worldwide",
  };

  return (
    <html lang="en" className={`${spaceGrotesk.variable} ${inter.variable} ${plexMono.variable}`}>
      <body className="bg-paper text-ink font-body antialiased selection:bg-cobalt selection:text-paper">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:top-4 focus:left-4 focus:bg-ink focus:text-paper focus:px-4 focus:py-2 focus:rounded"
        >
          Skip to content
        </a>
        <Navbar />
        <main id="main-content">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
