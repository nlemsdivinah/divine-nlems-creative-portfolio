import Link from "next/link";
import Image from "next/image";
import { client } from "@/lib/sanity.client";
import { siteSettingsQuery, featuredProjectsQuery, allServicesQuery, allTestimonialsQuery } from "@/lib/queries";
import { urlFor } from "@/lib/sanity.image";
import type { SiteSettings, Project, Service, Testimonial } from "@/lib/types";
import Hero from "@/components/Hero";
import StatCounter from "@/components/StatCounter";
import ServiceCard from "@/components/ServiceCard";
import TestimonialCard from "@/components/TestimonialCard";

export const revalidate = 60;

export default async function HomePage() {
  const [settings, featured, services, testimonials]: [SiteSettings, Project[], Service[], Testimonial[]] =
    await Promise.all([
      client.fetch(siteSettingsQuery),
      client.fetch(featuredProjectsQuery),
      client.fetch(allServicesQuery),
      client.fetch(allTestimonialsQuery),
    ]);

  return (
    <>
      <Hero settings={settings} />

      {settings?.clientLogos && settings.clientLogos.length > 0 && (
        <section className="hairline py-10">
          <div className="container-catalog flex flex-wrap items-center gap-10 justify-between opacity-70">
            {settings.clientLogos.map((logo, i) => (
              <div key={i} className="relative h-8 w-24 grayscale">
                <Image src={urlFor(logo).width(200).url()} alt="Client logo" fill className="object-contain" />
              </div>
            ))}
          </div>
        </section>
      )}

      {settings?.stats && settings.stats.length > 0 && (
        <section className="container-catalog py-16 grid grid-cols-2 md:grid-cols-4 gap-8">
          {settings.stats.map((s, i) => (
            <StatCounter key={i} value={s.value} suffix={s.suffix} label={s.label} />
          ))}
        </section>
      )}

      <section className="container-catalog py-16">
        <div className="flex items-end justify-between mb-10">
          <div>
            <p className="plate-number mb-2">FEATURED PLATES</p>
            <h2 className="text-display-2">Selected Work</h2>
          </div>
          <Link href="/portfolio" className="hidden sm:inline-block btn-secondary">Full index →</Link>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {featured.map((project) => (
            <Link key={project._id} href={`/portfolio/${project.slug.current}`} className="group block">
              <div className="relative aspect-[4/3] overflow-hidden border border-line mb-4">
                <Image
                  src={urlFor(project.coverImage).width(900).height(675).url()}
                  alt={project.coverImage.alt || project.title}
                  fill
                  className="object-cover group-hover:scale-[1.03] transition-transform duration-500 ease-out-quart"
                  sizes="(max-width: 768px) 100vw, 50vw"
                />
              </div>
              <div className="flex items-baseline justify-between">
                <h3 className="font-display font-bold text-xl group-hover:text-cobalt transition-colors">{project.title}</h3>
                <span className="plate-number">{String(project.plateNumber).padStart(2, "0")}</span>
              </div>
              <p className="text-sm text-ink/60">{project.industry} — {project.year}</p>
            </Link>
          ))}
        </div>
      </section>

      {services?.length > 0 && (
        <section className="bg-ink text-paper py-20">
          <div className="container-catalog">
            <p className="plate-number text-ochre mb-2">WHAT I DO</p>
            <h2 className="text-display-2 mb-10">Services</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {services.map((s, i) => (
                <div key={s._id} className="border border-paper/20 p-8">
                  <span className="plate-number text-ochre mb-4 block">{String(i + 1).padStart(2, "0")}</span>
                  <h3 className="font-display font-bold text-xl mb-3">{s.title}</h3>
                  <p className="text-paper/70 text-sm">{s.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {testimonials?.length > 0 && (
        <section className="container-catalog py-20">
          <p className="plate-number mb-2">CLIENT WORDS</p>
          <h2 className="text-display-2 mb-10">Testimonials</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {testimonials.slice(0, 4).map((t) => <TestimonialCard key={t._id} testimonial={t} />)}
          </div>
        </section>
      )}

      <section className="container-catalog pb-24 text-center">
        <h2 className="text-display-2 max-w-2xl mx-auto">Ready to add your project to the catalog?</h2>
        <Link href="/contact" className="btn-primary mt-8 inline-flex">Start a project</Link>
      </section>
    </>
  );
}
