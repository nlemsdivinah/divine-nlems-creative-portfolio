import type { Metadata } from "next";

export const metadata: Metadata = { title: "Terms of Service" };

export default function TermsPage() {
  return (
    <div className="container-catalog py-16 max-w-2xl mx-auto prose prose-neutral">
      <h1>Terms of Service</h1>
      <p>
        All project work, case studies, and images shown on this site remain the intellectual property of
        their respective owner unless otherwise agreed in writing. Client names, logos, and results shown
        in case studies are published with permission.
      </p>
      <p>
        Enquiries submitted through the contact form do not constitute a signed agreement. Project scope,
        pricing, and timelines are confirmed separately once details are discussed.
      </p>
      <p>
        Replace this placeholder with terms reviewed for your jurisdiction before launch — this text is a
        starting point, not legal advice.
      </p>
    </div>
  );
}
