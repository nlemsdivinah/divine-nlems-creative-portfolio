import type { Metadata } from "next";
import { client } from "@/lib/sanity.client";
import { allServicesQuery } from "@/lib/queries";
import type { Service } from "@/lib/types";
import ServiceCard from "@/components/ServiceCard";

export const revalidate = 60;

export const metadata: Metadata = {
  title: "Services",
  description: "Brand identity, packaging, social, and UI design services.",
};

export default async function ServicesPage() {
  const services: Service[] = await client.fetch(allServicesQuery);

  return (
    <div className="container-catalog py-16">
      <p className="plate-number mb-2">WHAT I DO</p>
      <h1 className="text-display-2 max-w-2xl mb-4">Services built around your launch, not my portfolio.</h1>
      <p className="text-ink/70 max-w-xl mb-12">
        Every engagement starts with your business problem, not a template. Below is what I offer —
        pick one, or tell me the outcome you need and I&apos;ll recommend a scope.
      </p>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {services.map((s, i) => <ServiceCard key={s._id} service={s} index={i} />)}
      </div>
    </div>
  );
}
