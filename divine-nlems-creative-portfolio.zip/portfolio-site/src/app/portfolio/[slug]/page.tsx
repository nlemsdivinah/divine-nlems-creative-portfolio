import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { client } from "@/lib/sanity.client";
import { projectBySlugQuery, allProjectSlugsQuery } from "@/lib/queries";
import { urlFor } from "@/lib/sanity.image";
import type { Project } from "@/lib/types";
import CaseStudy from "@/components/CaseStudy";

export const revalidate = 60;

export async function generateStaticParams() {
  const slugs: { slug: string }[] = await client.fetch(allProjectSlugsQuery);
  return slugs.map((s) => ({ slug: s.slug }));
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const project: Project | null = await client.fetch(projectBySlugQuery, { slug: params.slug });
  if (!project) return {};

  const description = project.summary || `Case study: ${project.title} for ${project.client}.`;
  const image = project.coverImage ? urlFor(project.coverImage).width(1200).height(630).url() : undefined;

  return {
    title: project.title,
    description,
    alternates: { canonical: `/portfolio/${project.slug.current}` },
    openGraph: { title: project.title, description, images: image ? [image] : undefined, type: "article" },
    twitter: { card: "summary_large_image", title: project.title, description, images: image ? [image] : undefined },
  };
}

export default async function ProjectPage({ params }: { params: { slug: string } }) {
  const project: Project | null = await client.fetch(projectBySlugQuery, { slug: params.slug });
  if (!project) notFound();
  return <CaseStudy project={project} />;
}
