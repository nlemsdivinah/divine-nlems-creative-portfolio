import type { Metadata } from "next";
import { client } from "@/lib/sanity.client";
import { allProjectsQuery } from "@/lib/queries";
import type { Project } from "@/lib/types";
import ProjectIndex from "@/components/ProjectIndex";

export const revalidate = 60;

export const metadata: Metadata = {
  title: "Portfolio Index",
  description: "The full catalog of branding, packaging, and digital design projects.",
};

export default async function PortfolioPage() {
  const projects: Project[] = await client.fetch(allProjectsQuery);
  return <ProjectIndex projects={projects} />;
}
