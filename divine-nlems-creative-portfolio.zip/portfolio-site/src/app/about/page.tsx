import type { Metadata } from "next";
import { PortableText } from "@portabletext/react";
import { client } from "@/lib/sanity.client";
import { siteSettingsQuery } from "@/lib/queries";
import type { SiteSettings } from "@/lib/types";
import ProcessTimeline from "@/components/ProcessTimeline";
import SkillsGrid from "@/components/SkillsGrid";

export const revalidate = 60;

export const metadata: Metadata = { title: "About" };

export default async function AboutPage() {
  const settings: SiteSettings = await client.fetch(siteSettingsQuery);

  return (
    <div className="container-catalog py-16 space-y-20">
      <header>
        <p className="plate-number mb-2">ABOUT</p>
        <h1 className="text-display-2 max-w-2xl mb-6">{settings?.mission || "Design with a point of view."}</h1>
        {settings?.bio && (
          <div className="prose prose-neutral max-w-2xl text-ink/80">
            <PortableText value={settings.bio} />
          </div>
        )}
        {settings?.resumeFile?.asset?.url && (
          <a href={settings.resumeFile.asset.url} download className="btn-primary mt-8 inline-flex">
            Download résumé
          </a>
        )}
      </header>

      {settings?.values && settings.values.length > 0 && (
        <section>
          <p className="plate-number mb-6">VALUES</p>
          <div className="grid sm:grid-cols-3 gap-6">
            {settings.values.map((v, i) => (
              <div key={i} className="border-t-2 border-ochre pt-4">
                <p className="font-display font-bold text-lg">{v}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      {settings?.timeline && settings.timeline.length > 0 && (
        <section>
          <p className="plate-number mb-6">JOURNEY</p>
          <ol className="space-y-6">
            {settings.timeline.map((t, i) => (
              <li key={i} className="flex gap-6 items-baseline">
                <span className="font-mono text-sm text-cobalt w-16 shrink-0">{t.year}</span>
                <span className="text-ink/80">{t.label}</span>
              </li>
            ))}
          </ol>
        </section>
      )}

      {settings?.process && settings.process.length > 0 && (
        <section>
          <p className="plate-number mb-6">HOW I WORK</p>
          <ProcessTimeline steps={settings.process} />
        </section>
      )}

      {settings?.skills && settings.skills.length > 0 && (
        <section>
          <p className="plate-number mb-6">SKILLS</p>
          <SkillsGrid skills={settings.skills} />
        </section>
      )}

      {settings?.awards && settings.awards.length > 0 && (
        <section>
          <p className="plate-number mb-6">AWARDS & CERTIFICATIONS</p>
          <ul className="grid sm:grid-cols-2 gap-3 font-mono text-sm text-ink/70">
            {settings.awards.map((a, i) => <li key={i}>— {a}</li>)}
          </ul>
        </section>
      )}
    </div>
  );
}
