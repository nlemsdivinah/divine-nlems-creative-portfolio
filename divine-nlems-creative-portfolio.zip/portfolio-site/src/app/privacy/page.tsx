import type { Metadata } from "next";

export const metadata: Metadata = { title: "Privacy Policy" };

export default function PrivacyPage() {
  return (
    <div className="container-catalog py-16 max-w-2xl mx-auto prose prose-neutral">
      <h1>Privacy Policy</h1>
      <p>
        This site collects only what&apos;s needed to respond to inquiries submitted through the contact
        form: your name, email address, and message. This information is used solely to reply to your
        enquiry and is not sold or shared with third parties beyond the email delivery provider used to
        send the message.
      </p>
      <p>
        The contact form is protected by Cloudflare Turnstile, which may process limited technical data
        (such as browser signals) to verify you are not a bot. See Cloudflare&apos;s own privacy policy for
        details on that processing.
      </p>
      <p>
        Replace this placeholder with a policy reviewed for your jurisdiction before launch — this text is
        a starting point, not legal advice.
      </p>
    </div>
  );
}
