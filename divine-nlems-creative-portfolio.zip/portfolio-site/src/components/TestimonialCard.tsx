import Image from "next/image";
import { urlFor } from "@/lib/sanity.image";
import type { Testimonial } from "@/lib/types";

export default function TestimonialCard({ testimonial }: { testimonial: Testimonial }) {
  return (
    <figure className="border border-line p-8 md:p-10 relative">
      <div className="flex gap-1 mb-4" aria-hidden="true">
        {Array.from({ length: 5 }).map((_, i) => (
          <span key={i} className={i < (testimonial.rating || 5) ? "text-ochre" : "text-line"}>★</span>
        ))}
      </div>
      <blockquote className="font-display text-xl md:text-2xl leading-snug mb-6">
        “{testimonial.quote}”
      </blockquote>
      <figcaption className="flex items-center gap-3">
        {testimonial.photo && (
          <div className="relative w-11 h-11 rounded-full overflow-hidden shrink-0">
            <Image src={urlFor(testimonial.photo).width(88).height(88).url()} alt={testimonial.name} fill className="object-cover" />
          </div>
        )}
        <div>
          <p className="font-medium text-sm">{testimonial.name}</p>
          {testimonial.role && <p className="font-mono text-xs text-ink/50">{testimonial.role}</p>}
        </div>
      </figcaption>
    </figure>
  );
}
