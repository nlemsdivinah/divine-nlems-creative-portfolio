import Link from "next/link";
import { client } from "@/lib/sanity.client";
import { siteSettingsQuery } from "@/lib/queries";
import type { SiteSettings } from "@/lib/types";
import BackToTop from "./BackToTop";
import NewsletterForm from "./NewsletterForm";

export default async function Footer() {
  const settings: SiteSettings = await client.fetch(siteSettingsQuery).catch(() => ({}));

  const socials = [
    { label: "LinkedIn", href: settings?.linkedin },
    { label: "Instagram", href: settings?.instagram },
    { label: "Behance", href: settings?.behance },
    { label: "Dribbble", href: settings?.dribbble },
  ].filter((s) => s.href);

  return (
    <footer className="hairline mt-32 bg-ink text-paper">
      <div className="container-catalog py-16 grid gap-12 md:grid-cols-3">
        <div>
          <p className="font-display font-bold text-2xl mb-3">
            Let&apos;s build something worth cataloguing.
          </p>
          <Link href="/contact" className="btn-primary bg-paper text-ink hover:bg-ochre hover:text-ink mt-2">
            Start a project
          </Link>
        </div>

        <div className="font-mono text-sm space-y-2 text-paper/80">
          <p>{settings?.email}</p>
          <p>{settings?.phone}</p>
          <p>{settings?.location}</p>
        </div>

        <div>
          <p className="font-mono text-sm text-paper/60 mb-3">Journal updates, occasionally.</p>
          <NewsletterForm />
        </div>
      </div>

      <div className="container-catalog border-t border-paper/15 py-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-paper/60">
        <p>© {new Date().getFullYear()} {settings?.siteName || "Divine Nlems"}. All rights reserved.</p>
        <ul className="flex gap-5">
          {socials.map((s) => (
            <li key={s.label}>
              <a href={s.href} target="_blank" rel="noopener noreferrer" className="hover:text-paper">
                {s.label}
              </a>
            </li>
          ))}
          <li><Link href="/privacy" className="hover:text-paper">Privacy</Link></li>
          <li><Link href="/terms" className="hover:text-paper">Terms</Link></li>
        </ul>
        <BackToTop />
      </div>
    </footer>
  );
}
