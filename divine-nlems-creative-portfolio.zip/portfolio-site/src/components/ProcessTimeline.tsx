"use client";

import { motion } from "framer-motion";

export default function ProcessTimeline({ steps }: { steps: { title: string; description: string }[] }) {
  return (
    <ol className="hairline">
      {steps.map((step, i) => (
        <motion.li
          key={step.title}
          initial={{ opacity: 0, x: -12 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.4, delay: i * 0.05 }}
          className="border-b border-line py-8 grid md:grid-cols-[100px_1fr] gap-4"
        >
          <span className="font-mono text-sm text-cobalt">{String(i + 1).padStart(2, "0")}</span>
          <div>
            <h3 className="font-display font-bold text-xl mb-1">{step.title}</h3>
            <p className="text-ink/70 text-sm max-w-xl">{step.description}</p>
          </div>
        </motion.li>
      ))}
    </ol>
  );
}
