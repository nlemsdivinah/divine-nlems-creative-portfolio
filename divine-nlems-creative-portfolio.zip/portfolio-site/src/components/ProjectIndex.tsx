"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import { urlFor } from "@/lib/sanity.image";
import type { Project } from "@/lib/types";

export default function ProjectIndex({ projects }: { projects: Project[] }) {
  const [query, setQuery] = useState("");
  const [industry, setIndustry] = useState("All");
  const [hovered, setHovered] = useState<Project | null>(null);

  const industries = useMemo(
    () => ["All", ...Array.from(new Set(projects.map((p) => p.industry).filter(Boolean)))],
    [projects]
  ) as string[];

  const filtered = projects.filter((p) => {
    const matchesIndustry = industry === "All" || p.industry === industry;
    const matchesQuery =
      !query ||
      p.title.toLowerCase().includes(query.toLowerCase()) ||
      p.client?.toLowerCase().includes(query.toLowerCase());
    return matchesIndustry && matchesQuery;
  });

  return (
    <div className="container-catalog py-16">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
        <div>
          <p className="plate-number mb-2">SELECTED WORKS</p>
          <h1 className="text-display-2">The Index</h1>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <label className="sr-only" htmlFor="project-search">Search projects</label>
          <input
            id="project-search"
            type="search"
            placeholder="Search by title or client…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="border border-line rounded-full px-4 py-2 text-sm font-mono w-full sm:w-64 focus-visible:border-cobalt"
          />
          <select
            aria-label="Filter by industry"
            value={industry}
            onChange={(e) => setIndustry(e.target.value)}
            className="border border-line rounded-full px-4 py-2 text-sm font-mono bg-paper"
          >
            {industries.map((i) => (
              <option key={i} value={i}>{i}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid md:grid-cols-[1fr_360px] gap-10">
        <ul className="hairline">
          {filtered.map((project, i) => (
            <motion.li
              key={project._id}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.4, delay: i * 0.03 }}
              className="border-b border-line"
              onMouseEnter={() => setHovered(project)}
              onMouseLeave={() => setHovered(null)}
            >
              <Link
                href={`/portfolio/${project.slug.current}`}
                className="group flex items-baseline gap-6 py-6 focus-visible:bg-ink/5"
              >
                <span className="plate-number w-16 shrink-0">
                  {String(project.plateNumber).padStart(2, "0")}
                </span>
                <span className="font-display font-bold text-2xl md:text-3xl group-hover:text-cobalt transition-colors flex-1">
                  {project.title}
                </span>
                <span className="hidden sm:block font-mono text-xs text-ink/50">{project.industry}</span>
                <span className="hidden sm:block font-mono text-xs text-ink/50 w-12 text-right">{project.year}</span>
                <span className="opacity-0 group-hover:opacity-100 transition-opacity">→</span>
              </Link>
            </motion.li>
          ))}
          {filtered.length === 0 && (
            <li className="py-12 text-center font-mono text-sm text-ink/50">
              No plates match that search. Try another term or clear the filter.
            </li>
          )}
        </ul>

        <div className="hidden md:block sticky top-28 h-fit">
          <div className="aspect-[4/5] relative border border-line bg-ink/5 overflow-hidden">
            {hovered ? (
              <Image
                src={urlFor(hovered.coverImage).width(720).height(900).url()}
                alt={hovered.coverImage.alt || hovered.title}
                fill
                className="object-cover"
                sizes="360px"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center font-mono text-xs text-ink/40 p-6 text-center">
                Hover a plate to preview the work
              </div>
            )}
          </div>
          {hovered?.summary && (
            <p className="mt-3 font-mono text-xs text-ink/60">{hovered.summary}</p>
          )}
        </div>
      </div>
    </div>
  );
}
