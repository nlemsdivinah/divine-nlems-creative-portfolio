"use client";

import { useRef, useState } from "react";
import Script from "next/script";

declare global {
  interface Window {
    turnstile?: {
      render: (container: string | HTMLElement, options: Record<string, unknown>) => string;
      reset: (widgetId?: string) => void;
    };
  }
}

type Status = "idle" | "submitting" | "success" | "error";

export default function ContactForm() {
  const [status, setStatus] = useState<Status>("idle");
  const [errorMsg, setErrorMsg] = useState("");
  const [turnstileToken, setTurnstileToken] = useState("");
  const widgetRef = useRef<HTMLDivElement>(null);

  function renderTurnstile() {
    if (!window.turnstile || !widgetRef.current || widgetRef.current.childElementCount > 0) return;
    window.turnstile.render(widgetRef.current, {
      sitekey: process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY,
      callback: (token: string) => setTurnstileToken(token),
      theme: "light",
    });
  }

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus("submitting");
    setErrorMsg("");

    const form = e.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());

    if (!turnstileToken) {
      setStatus("error");
      setErrorMsg("Please complete the verification check.");
      return;
    }

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...data, turnstileToken }),
      });
      const json = await res.json();

      if (!res.ok || !json.ok) {
        throw new Error(json.error || "Something went wrong.");
      }

      setStatus("success");
      form.reset();
      window.turnstile?.reset();
      setTurnstileToken("");
    } catch (err) {
      setStatus("error");
      setErrorMsg(err instanceof Error ? err.message : "Something went wrong.");
    }
  }

  if (status === "success") {
    return (
      <div className="border border-line p-10 text-center" role="status">
        <p className="font-display font-bold text-2xl mb-2">Message sent.</p>
        <p className="text-ink/70">Thanks for reaching out — I typically reply within one business day.</p>
      </div>
    );
  }

  return (
    <>
      <Script src="https://challenges.cloudflare.com/turnstile/v0/api.js" strategy="lazyOnload" onLoad={renderTurnstile} />
      <form onSubmit={onSubmit} className="space-y-6" noValidate>
        {/* Honeypot field — hidden from real users, visible to bots */}
        <div className="hidden" aria-hidden="true">
          <label htmlFor="company">Company</label>
          <input id="company" name="company" type="text" tabIndex={-1} autoComplete="off" />
        </div>

        <div className="grid sm:grid-cols-2 gap-6">
          <div>
            <label htmlFor="name" className="block font-mono text-xs uppercase tracking-wide mb-2">Name</label>
            <input
              id="name" name="name" type="text" required minLength={2} maxLength={100}
              className="w-full border-b border-line bg-transparent py-2 focus-visible:border-cobalt"
            />
          </div>
          <div>
            <label htmlFor="email" className="block font-mono text-xs uppercase tracking-wide mb-2">Email</label>
            <input
              id="email" name="email" type="email" required maxLength={200}
              className="w-full border-b border-line bg-transparent py-2 focus-visible:border-cobalt"
            />
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-6">
          <div>
            <label htmlFor="projectType" className="block font-mono text-xs uppercase tracking-wide mb-2">Project type</label>
            <select id="projectType" name="projectType" className="w-full border-b border-line bg-transparent py-2 focus-visible:border-cobalt">
              <option>Brand identity</option>
              <option>Logo design</option>
              <option>Packaging</option>
              <option>Social media design</option>
              <option>UI design</option>
              <option>Other</option>
            </select>
          </div>
          <div>
            <label htmlFor="budget" className="block font-mono text-xs uppercase tracking-wide mb-2">Budget range</label>
            <select id="budget" name="budget" className="w-full border-b border-line bg-transparent py-2 focus-visible:border-cobalt">
              <option>Under $500</option>
              <option>$500 – $1,500</option>
              <option>$1,500 – $5,000</option>
              <option>$5,000+</option>
            </select>
          </div>
        </div>

        <div>
          <label htmlFor="message" className="block font-mono text-xs uppercase tracking-wide mb-2">Project details</label>
          <textarea
            id="message" name="message" required minLength={10} maxLength={3000} rows={5}
            className="w-full border-b border-line bg-transparent py-2 focus-visible:border-cobalt resize-none"
          />
        </div>

        <div ref={widgetRef} />

        {status === "error" && (
          <p className="text-sm text-red-600" role="alert">{errorMsg}</p>
        )}

        <button type="submit" disabled={status === "submitting"} className="btn-primary disabled:opacity-60">
          {status === "submitting" ? "Sending…" : "Send message"}
        </button>
      </form>
    </>
  );
}
