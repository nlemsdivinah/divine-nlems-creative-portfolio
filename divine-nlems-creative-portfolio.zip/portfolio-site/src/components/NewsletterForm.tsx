"use client";

import { useState } from "react";

export default function NewsletterForm() {
  const [status, setStatus] = useState<"idle" | "loading" | "done">("idle");

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus("loading");
    // Wire this up to your ESP of choice (Mailchimp, ConvertKit, Resend Audiences, etc.)
    // via a small /api/newsletter route mirroring the contact route's pattern.
    await new Promise((r) => setTimeout(r, 600));
    setStatus("done");
  }

  if (status === "done") {
    return <p className="font-mono text-sm text-ochre-light">You&apos;re on the list.</p>;
  }

  return (
    <form onSubmit={onSubmit} className="flex gap-2">
      <label htmlFor="newsletter-email" className="sr-only">Email address</label>
      <input
        id="newsletter-email"
        type="email"
        required
        placeholder="you@email.com"
        className="flex-1 min-w-0 bg-transparent border border-paper/30 rounded-full px-4 py-2 text-sm placeholder:text-paper/40 focus-visible:border-paper"
      />
      <button
        type="submit"
        disabled={status === "loading"}
        className="rounded-full bg-paper text-ink px-4 py-2 text-sm font-medium disabled:opacity-60"
      >
        {status === "loading" ? "..." : "Join"}
      </button>
    </form>
  );
}
