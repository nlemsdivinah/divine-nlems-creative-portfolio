"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { urlFor } from "@/lib/sanity.image";
import type { SiteSettings } from "@/lib/types";

export default function Hero({ settings }: { settings: SiteSettings }) {
  return (
    <section className="container-catalog pt-16 md:pt-24 pb-20 grid md:grid-cols-[1.3fr_1fr] gap-12 items-end">
      <div>
        <motion.p
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="plate-number mb-6"
        >
          CATALOG — {settings?.availability || "Currently booking new work"}
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.25, 1, 0.5, 1] }}
          className="text-display-1"
        >
          {settings?.heroHeadline || "Brands, catalogued and considered."}
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.15, ease: [0.25, 1, 0.5, 1] }}
          className="mt-6 max-w-xl text-lg text-ink/70"
        >
          {settings?.heroSubheadline ||
            "I'm Divine, a creative graphic designer. Every project below is documented like a plate in a design annual — the problem, the process, and the result."}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="mt-9 flex flex-wrap gap-4"
        >
          <Link href="/contact" className="btn-primary">Hire me</Link>
          <Link href="/portfolio" className="btn-secondary">View the index →</Link>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, ease: [0.25, 1, 0.5, 1] }}
        className="relative aspect-[4/5] w-full max-w-sm md:justify-self-end"
      >
        {settings?.heroPortrait ? (
          <Image
            src={urlFor(settings.heroPortrait).width(700).height(875).url()}
            alt={settings.heroPortrait.alt || "Portrait"}
            fill
            priority
            className="object-cover grayscale-[15%]"
            sizes="(max-width: 768px) 90vw, 400px"
          />
        ) : (
          <div className="w-full h-full bg-ink/5 border border-line flex items-center justify-center font-mono text-sm text-ink/40">
            Portrait placeholder
          </div>
        )}
        <div className="absolute -bottom-3 -left-3 border border-ink px-3 py-1 bg-paper font-mono text-xs">
          Plate 000 — Self
        </div>
      </motion.div>
    </section>
  );
}
