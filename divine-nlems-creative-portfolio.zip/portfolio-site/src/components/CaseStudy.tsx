"use client";

import Image from "next/image";
import { PortableText } from "@portabletext/react";
import { motion } from "framer-motion";
import { urlFor } from "@/lib/sanity.image";
import type { Project } from "@/lib/types";
import Lightbox from "./Lightbox";
import TestimonialCard from "./TestimonialCard";

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-60px" },
  transition: { duration: 0.5, ease: [0.25, 1, 0.5, 1] as const },
};

function MetaRow({ project }: { project: Project }) {
  const items = [
    { label: "Client", value: project.client },
    { label: "Industry", value: project.industry },
    { label: "Year", value: project.year },
  ].filter((i) => i.value);

  return (
    <dl className="grid grid-cols-2 sm:grid-cols-4 gap-6 font-mono text-sm border-y border-line py-6">
      {items.map((i) => (
        <div key={i.label}>
          <dt className="text-ink/50 text-xs uppercase tracking-wide mb-1">{i.label}</dt>
          <dd className="font-medium">{i.value}</dd>
        </div>
      ))}
      {project.links?.liveUrl && (
        <div>
          <dt className="text-ink/50 text-xs uppercase tracking-wide mb-1">Live</dt>
          <dd>
            <a href={project.links.liveUrl} target="_blank" rel="noopener noreferrer" className="underline hover:text-cobalt">
              Visit site ↗
            </a>
          </dd>
        </div>
      )}
    </dl>
  );
}

export default function CaseStudy({ project }: { project: Project }) {
  const galleryImages = project.gallery || [];

  return (
    <article>
      <header className="container-catalog pt-14 pb-8">
        <p className="plate-number mb-4">PLATE {String(project.plateNumber).padStart(2, "0")}</p>
        <h1 className="text-display-2 max-w-3xl">{project.title}</h1>
        {project.summary && <p className="mt-4 max-w-2xl text-lg text-ink/70">{project.summary}</p>}
      </header>

      <div className="container-catalog"><MetaRow project={project} /></div>

      <div className="relative w-full aspect-[16/9] mt-8">
        <Image
          src={urlFor(project.coverImage).width(2000).height(1125).url()}
          alt={project.coverImage.alt || project.title}
          fill
          priority
          className="object-cover"
          sizes="100vw"
        />
      </div>

      <div className="container-catalog py-16 grid md:grid-cols-[220px_1fr] gap-10">
        <aside className="font-mono text-xs uppercase tracking-wide text-ink/50 space-y-8">
          {project.objectives && project.objectives.length > 0 && (
            <div>
              <p className="mb-2 text-ink/70">Objectives</p>
              <ul className="space-y-1 normal-case font-body text-sm text-ink/80">
                {project.objectives.map((o, i) => <li key={i}>— {o}</li>)}
              </ul>
            </div>
          )}
          {project.toolsUsed && project.toolsUsed.length > 0 && (
            <div>
              <p className="mb-2 text-ink/70">Tools</p>
              <ul className="space-y-1 normal-case font-body text-sm text-ink/80">
                {project.toolsUsed.map((t, i) => <li key={i}>{t}</li>)}
              </ul>
            </div>
          )}
          {project.typography && project.typography.length > 0 && (
            <div>
              <p className="mb-2 text-ink/70">Typography</p>
              <ul className="space-y-1 normal-case font-body text-sm text-ink/80">
                {project.typography.map((t, i) => <li key={i}>{t}</li>)}
              </ul>
            </div>
          )}
          {project.colorPalette && project.colorPalette.length > 0 && (
            <div>
              <p className="mb-2 text-ink/70">Palette</p>
              <div className="flex flex-wrap gap-2">
                {project.colorPalette.map((c, i) => (
                  <span
                    key={i}
                    title={c}
                    className="w-8 h-8 rounded-full border border-line"
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
            </div>
          )}
        </aside>

        <div className="space-y-16">
          {project.problem && (
            <motion.section {...fadeUp}>
              <h2 className="text-2xl font-display font-bold mb-4">The problem</h2>
              <div className="prose prose-neutral max-w-2xl text-ink/80">
                <PortableText value={project.problem} />
              </div>
            </motion.section>
          )}

          {project.process && (
            <motion.section {...fadeUp}>
              <h2 className="text-2xl font-display font-bold mb-4">Creative process</h2>
              <div className="prose prose-neutral max-w-2xl text-ink/80">
                <PortableText value={project.process} />
              </div>
            </motion.section>
          )}

          {project.brandStrategy && (
            <motion.section {...fadeUp}>
              <h2 className="text-2xl font-display font-bold mb-4">Brand strategy</h2>
              <div className="prose prose-neutral max-w-2xl text-ink/80">
                <PortableText value={project.brandStrategy} />
              </div>
            </motion.section>
          )}

          {project.solution && (
            <motion.section {...fadeUp}>
              <h2 className="text-2xl font-display font-bold mb-4">The solution</h2>
              <div className="prose prose-neutral max-w-2xl text-ink/80">
                <PortableText value={project.solution} />
              </div>
            </motion.section>
          )}

          {project.beforeAfter?.before && project.beforeAfter?.after && (
            <motion.section {...fadeUp}>
              <h2 className="text-2xl font-display font-bold mb-4">Before / after</h2>
              <div className="grid grid-cols-2 gap-4">
                <div className="relative aspect-square">
                  <Image src={urlFor(project.beforeAfter.before).width(700).height(700).url()} alt="Before" fill className="object-cover" />
                  <span className="absolute top-3 left-3 bg-ink text-paper text-xs font-mono px-2 py-1">Before</span>
                </div>
                <div className="relative aspect-square">
                  <Image src={urlFor(project.beforeAfter.after).width(700).height(700).url()} alt="After" fill className="object-cover" />
                  <span className="absolute top-3 left-3 bg-cobalt text-paper text-xs font-mono px-2 py-1">After</span>
                </div>
              </div>
            </motion.section>
          )}

          {galleryImages.length > 0 && (
            <motion.section {...fadeUp}>
              <h2 className="text-2xl font-display font-bold mb-4">Gallery</h2>
              <Lightbox images={galleryImages} />
            </motion.section>
          )}

          {project.results && project.results.length > 0 && (
            <motion.section {...fadeUp} className="bg-ink text-paper p-8 md:p-10 -mx-6 md:mx-0">
              <h2 className="text-2xl font-display font-bold mb-5">Results</h2>
              <ul className="grid sm:grid-cols-2 gap-4 font-mono text-sm">
                {project.results.map((r, i) => (
                  <li key={i} className="border-l-2 border-ochre pl-4 py-1">{r}</li>
                ))}
              </ul>
            </motion.section>
          )}

          {project.testimonial && (
            <motion.section {...fadeUp}>
              <TestimonialCard testimonial={project.testimonial} />
            </motion.section>
          )}

          {(project.links?.behance || project.links?.dribbble || project.links?.github) && (
            <motion.section {...fadeUp} className="flex flex-wrap gap-4 pt-4">
              {project.links.behance && <a href={project.links.behance} className="btn-secondary" target="_blank" rel="noopener noreferrer">View on Behance ↗</a>}
              {project.links.dribbble && <a href={project.links.dribbble} className="btn-secondary" target="_blank" rel="noopener noreferrer">View on Dribbble ↗</a>}
              {project.links.github && <a href={project.links.github} className="btn-secondary" target="_blank" rel="noopener noreferrer">View on GitHub ↗</a>}
            </motion.section>
          )}
        </div>
      </div>
    </article>
  );
}
