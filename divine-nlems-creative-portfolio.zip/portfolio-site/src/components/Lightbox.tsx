"use client";

import { useState, useCallback, useEffect } from "react";
import Image from "next/image";
import { AnimatePresence, motion } from "framer-motion";
import { urlFor } from "@/lib/sanity.image";
import type { SanityImageAsset } from "@/lib/types";

export default function Lightbox({ images }: { images: SanityImageAsset[] }) {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const close = useCallback(() => setActiveIndex(null), []);
  const next = useCallback(() => setActiveIndex((i) => (i === null ? null : (i + 1) % images.length)), [images.length]);
  const prev = useCallback(
    () => setActiveIndex((i) => (i === null ? null : (i - 1 + images.length) % images.length)),
    [images.length]
  );

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (activeIndex === null) return;
      if (e.key === "Escape") close();
      if (e.key === "ArrowRight") next();
      if (e.key === "ArrowLeft") prev();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [activeIndex, close, next, prev]);

  return (
    <>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {images.map((img, i) => (
          <button
            key={i}
            onClick={() => setActiveIndex(i)}
            className="relative aspect-square focus-visible:outline focus-visible:outline-2 focus-visible:outline-cobalt"
            aria-label={`Open image ${i + 1} of ${images.length}`}
          >
            <Image
              src={urlFor(img).width(500).height(500).url()}
              alt={img.alt || `Gallery image ${i + 1}`}
              fill
              className="object-cover hover:opacity-80 transition-opacity"
              sizes="(max-width: 768px) 45vw, 300px"
            />
          </button>
        ))}
      </div>

      <AnimatePresence>
        {activeIndex !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-ink/95 flex items-center justify-center p-6"
            role="dialog"
            aria-modal="true"
            aria-label="Image viewer"
          >
            <button onClick={close} className="absolute top-6 right-6 text-paper text-3xl leading-none" aria-label="Close viewer">
              ×
            </button>
            <button onClick={prev} className="absolute left-4 md:left-8 text-paper text-2xl p-2" aria-label="Previous image">‹</button>
            <button onClick={next} className="absolute right-4 md:right-8 text-paper text-2xl p-2" aria-label="Next image">›</button>

            <motion.div
              key={activeIndex}
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              className="relative w-full max-w-4xl aspect-[4/3]"
            >
              <Image
                src={urlFor(images[activeIndex]).width(1600).height(1200).url()}
                alt={images[activeIndex].alt || "Gallery image"}
                fill
                className="object-contain"
                sizes="90vw"
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
