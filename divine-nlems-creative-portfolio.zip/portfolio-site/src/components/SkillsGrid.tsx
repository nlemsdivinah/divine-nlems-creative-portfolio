"use client";

import { motion } from "framer-motion";

export default function SkillsGrid({ skills }: { skills: { name: string; level: number }[] }) {
  return (
    <div className="grid sm:grid-cols-2 gap-x-10 gap-y-6">
      {skills.map((skill, i) => (
        <div key={skill.name}>
          <div className="flex justify-between font-mono text-xs mb-2">
            <span>{skill.name}</span>
            <span className="text-ink/50">{skill.level}%</span>
          </div>
          <div className="h-1.5 bg-ink/10 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              whileInView={{ width: `${skill.level}%` }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: i * 0.05, ease: [0.25, 1, 0.5, 1] }}
              className="h-full bg-cobalt rounded-full"
            />
          </div>
        </div>
      ))}
    </div>
  );
}
