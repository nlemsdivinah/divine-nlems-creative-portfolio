import Link from "next/link";
import type { Service } from "@/lib/types";

export default function ServiceCard({ service, index }: { service: Service; index: number }) {
  return (
    <div className="border border-line p-8 flex flex-col h-full hover:border-cobalt transition-colors">
      <span className="plate-number mb-4">{String(index + 1).padStart(2, "0")}</span>
      <h3 className="font-display font-bold text-xl mb-3">{service.title}</h3>
      <p className="text-ink/70 text-sm mb-4 flex-1">{service.description}</p>
      {service.benefits && service.benefits.length > 0 && (
        <ul className="space-y-1.5 mb-6 font-mono text-xs text-ink/60">
          {service.benefits.map((b, i) => <li key={i}>— {b}</li>)}
        </ul>
      )}
      {service.startingPrice && (
        <p className="font-mono text-xs text-ink/50 mb-4">From {service.startingPrice}</p>
      )}
      <Link href="/contact" className="text-sm font-medium underline underline-offset-4 hover:text-cobalt">
        {service.ctaLabel || "Start a project"} →
      </Link>
    </div>
  );
}
