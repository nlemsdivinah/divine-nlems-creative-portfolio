"use client";

export default function BackToTop() {
  return (
    <button
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      className="hover:text-paper underline underline-offset-4"
      aria-label="Back to top"
    >
      Back to top ↑
    </button>
  );
}
